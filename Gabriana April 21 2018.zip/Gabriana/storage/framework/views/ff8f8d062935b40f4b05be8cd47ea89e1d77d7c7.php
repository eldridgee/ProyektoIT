<?php $__env->startSection('content'); ?>
    <section class="content-header">
    <h1>
        <?php echo e($patient->name); ?>

    </h1>
    <ol class="breadcrumb">
        <li><a href=<?php echo e(url('/admin')); ?>><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(url('/admin/patient')); ?>">Records</a></li>
    </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <th> Name </th>
                                        <td> <?php echo e($patient->name); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Address </th>
                                        <td> <?php echo e($patient->address); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Occupation </th>
                                        <td> <?php echo e($patient->occupation); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Contact Number </th>
                                        <td> <?php echo e($patient->patientTelNo); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Civil Status</th>
                                        <td> <?php echo e($patient->status); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Date of Birth </th>
                                        <td> <?php echo e($patient->birthDate); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Age </th>
                                        <td> <?php echo e($patient->age); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Gender </th>
                                        <td> <?php echo e($patient->sex); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Medical Conditions </th>
                                        <td> <?php echo e($patient->medconditions); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Allergies </th>
                                        <td> <?php echo e($patient->allergies); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Balance </th>
                                        <td> <?php echo e($patient->balance); ?>  </td>
                                    </tr>
                                    <tr>
                                        <th> Patient Status </th>
                                        <td> <?php echo e($patient->patStatus); ?>  </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.box-body -->
                        <div class="modal fade" id="modalCart" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <!--Header-->
                                    <div class="modal-header">
                                        <h1 class="modal-title" id="myModalLabel"><?php echo e($patient->name); ?></h1>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <!--Body-->
                                    <div class="modal-body">
                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <h3><?php echo e($schedule->date); ?></h3>
                                            <hr>
                                            <table class="table table-hover">
                                                <tbody>
                                                    <tr>
                                                        <th style="width: 50%">Date</th>
                                                        <td><?php echo e($schedule->date); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 50%">Time From</th>
                                                        <td><?php echo e($schedule->timeFrom); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 50%">Time To</th>
                                                        <td><?php echo e($schedule->timeTo); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 50%">Operation Status</th>
                                                        <td><?php echo e($schedule->opStatus); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 50%">Dentist</th>
                                                        <td><?php echo e($schedule->dentist->name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th style="width: 50%">Services</th>
                                                        <td><?php echo e($schedule->service->servName); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Balance</th>
                                                        <td><?php echo e($patient->balance); ?></td>
                                                        <th></th>
                                                        <td><button class="btn btn-success">Pay</button></td>
                                                    </tr>    
                                                </tbody>
                                            </table>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <!--Footer-->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                                        <button class="btn btn-primary">Checkout</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <a href="<?php echo e(url('/admin/patient')); ?>" class="btn btn-warning">Cancel</a>
                            <button class="btn btn-primary"data-toggle="modal" data-target="#modalCart">History</button>
                            <a href="<?php echo e(url('/admin/patient' . '/' .$patient->patID . '/edit')); ?>" class="btn btn-primary pull-right">Edit</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>