<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Create Schedule
        </h1>
        <hr>
        <ol class="breadcrumb">
            <li><a href="/admin"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Schedule</li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                    

                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                        <div class="form-group" <?php echo e($errors->has('patID') ? 'has-error' : ''); ?>>
                            <?php echo e(Form::label('patID', 'Patient Name')); ?>

                            <select name="patID" class="form-control">
                                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($patient); ?>"><?php echo e($patient->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <?php echo Form::open(['action' => 'Admin\\SchedulesController@store', 'method' => 'POST']); ?>

                            <?php echo e(csrf_field()); ?>

                            
                            <div class="form-group" <?php echo e($errors->has('date') ? 'has-error' : ''); ?>>
                                <?php echo e(Form::label('date', 'Date')); ?>

                                <?php echo e(Form::date('date', '', ['class' => 'form-control'])); ?>

                            </div>
                            <div class="form-group" <?php echo e($errors->has('timeFrom') ? 'has-error' : ''); ?>>
                                <?php echo e(Form::label('timeFrom', 'Time From')); ?>

                                <?php echo e(Form::time('timeFrom', '', ['class' => 'form-control'])); ?>

                            </div>
                            <div class="form-group" <?php echo e($errors->has('timeTo') ? 'has-error' : ''); ?>>
                                <?php echo e(Form::label('timeTo', 'Time To')); ?>

                                <?php echo e(Form::time('timeTo', '', ['class' => 'form-control', 'placeholder' => 'First name followed by Last Name'])); ?>

                            </div>
                            <div class="form-group" <?php echo e($errors->has('servID') ? 'has-error' : ''); ?>>
                                <?php echo e(Form::label('servID', 'Service')); ?>

                                <select name="servID" class="form-control">
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($service); ?>"><?php echo e($service->servName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>


                        <div class="form-group" <?php echo e($errors->has('dentID') ? 'has-error' : ''); ?>> 
                            <?php echo e(Form::label('dentID', 'Dentist')); ?>                              
                            <select name="dentID" class="form-control">
                                <?php $__currentLoopData = $dentists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dentist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dentist); ?>"><?php echo e($dentist->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <a href="<?php echo e(url('/admin/schedules')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>