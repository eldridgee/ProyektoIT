<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Edit inventory item
            </h1>
            <ol class="breadcrumb">
                <li><a href="/home"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="">Inventory</li>
                <li class="active">Edit Inventory</li>
            </ol>
        </section>

        <div class="well">
            <?php echo Form::open(['action' => ['InventoryController@update', $inventory->invID], 'method' => 'POST']); ?>

            
            <div class="form-group">
                <?php echo e(Form::label('invName', 'Name')); ?>

                <?php echo e(Form::text('invName', $inventory->invName, ['class' => 'form-control', 'placeholder' => 'Inventory Name'])); ?>

            </div>

            <div class="form-group">
                    <?php echo e(Form::label('quantity', 'Quantity')); ?>

                    <?php echo e(Form::text('quantity', $inventory->quantity, ['class' => 'form-control', 'placeholder' => 'Initial Quantity'])); ?>

            </div>

            <div class="form-group">
                    <?php echo e(Form::label('low_stock_quantity', 'Low Stock Quantity')); ?>

                    <?php echo e(Form::text('low_stock_quantity', $inventory->low_stock_quantity, ['class' => 'form-control', 'placeholder' => 'Enter the Low Stock Quantity'])); ?>

            </div>

            <div class="form-group">
                    <?php echo e(Form::label('unit', 'Unit Category')); ?>

                    <?php echo e(Form::text('unit', $inventory->unit, ['class' => 'form-control', 'placeholder' => 'Enter the Unit category (e.g. Box, Pieces)'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::label('invStatus', 'Inventory Status')); ?>

                <?php echo e(Form::text('invStatus', $inventory->invStatus, ['class' => 'form-control', 'placeholder' => 'e.g. Low in Stock, No Stock, Good'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::label('status', 'Status')); ?>

                <?php echo e(Form::text('status', $inventory->status, ['class' => 'form-control', 'placeholder' => 'Active or Inactive'])); ?>

            </div>
            <?php echo e(Form::hidden('_method', 'PUT')); ?>

           <center> <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary'])); ?> </center>
            <?php echo Form::close(); ?>

        </div>
      
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>