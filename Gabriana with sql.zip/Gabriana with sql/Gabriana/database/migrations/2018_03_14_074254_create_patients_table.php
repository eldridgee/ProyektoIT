<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->increments('patID');
            $table->string('name');
            $table->string('address');
            $table->string('occupation');
            $table->string('patientTelNo');
            $table->string('status');
            $table->date('birthDate');
            $table->string('age');
            $table->string('sex');
            $table->string('medconditions');
            $table->string('allergies');
            $table->string('balance');
            $table->string('patStatus');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients');
    }
}
