-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2018 at 01:03 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gab`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `apptID` int(11) NOT NULL,
  `services` varchar(45) NOT NULL,
  `date` date NOT NULL,
  `invUsed` varchar(45) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `bill` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dental_clinic_assistant`
--

CREATE TABLE `dental_clinic_assistant` (
  `asstID` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `asstTelNO` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dentist`
--

CREATE TABLE `dentist` (
  `dentID` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `dentTelNo` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dentistservices`
--

CREATE TABLE `dentistservices` (
  `serPerformed` int(11) NOT NULL,
  `dentAssigned` varchar(45) NOT NULL,
  `timePerformed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `servDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `histID` int(11) NOT NULL,
  `dateAdded` date DEFAULT NULL,
  `timeAdded` varchar(45) DEFAULT NULL,
  `invAdded` int(11) DEFAULT NULL,
  `qtyUnused` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `invID` int(10) UNSIGNED NOT NULL,
  `invName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `low_stock_quantity` int(11) NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invStatus` enum('Out of Stock','Low in Stock','Good') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`invID`, `invName`, `quantity`, `low_stock_quantity`, `unit`, `invStatus`, `status`) VALUES
(1, '2 To 4 HOLES ADAPTER', 5, 50, 'pcs', 'Low in Stock', 'active'),
(2, '4 TO TO', 1, 50, 'pcs', 'Low in Stock', 'active'),
(3, 'Alginate/Kromopan', 11, 50, 'kilos', 'Low in Stock', 'active'),
(4, 'Anesthesia', 10, 50, 'pcs', 'Low in Stock', 'active'),
(5, 'Applicator tips', 4, 50, 'pcs', 'Good', 'active'),
(6, 'Articulating Paper', 21, 50, 'pcs', 'Low in Stock', 'active'),
(7, 'Barbed Roach', 8, 50, 'pcs', 'Good', 'active'),
(8, 'BEAUTI-CEMENT', 1, 50, 'pcs', 'Low in Stock', 'active'),
(9, 'big diamonds finishing burr', 1, 50, 'pcs', 'Low in Stock', 'active'),
(10, 'Bite Block', 8, 50, 'pcs', 'Low in Stock', 'active'),
(11, 'Bite Wax', 37, 50, 'pcs', 'Low in Stock', 'active'),
(12, 'Bone Burrs', 6, 50, 'pcs', 'Low in Stock', 'active'),
(13, 'BONDING agent', 1, 50, 'pcs', 'Low in Stock', 'active'),
(14, 'Brackets', 26, 50, 'set', 'Low in Stock', 'active'),
(15, 'Buccal Tubes', 0, 50, 'set', 'Out of Stock', 'inactive'),
(16, 'Burr -40 round', 2, 50, 'pcs', 'Low in Stock', 'active'),
(17, 'Burrs # 368016', 3, 50, 'pcs', 'Low in Stock', 'active'),
(18, 'Burrs diamond point (FG)', 5, 50, 'pcs', 'Low in Stock', 'active'),
(19, 'Calibra esthetic Resin Cement', 3, 50, 'pcs', 'Low in Stock', 'active'),
(20, 'Castone', 12, 50, 'pcs', 'Low in Stock', 'active'),
(21, 'Cavitron', 1, 50, 'pcs', 'Low in Stock', 'active'),
(22, 'Celluloid Strip', 4, 50, 'pcs', 'Low in Stock', 'active'),
(23, 'Ceramic Brackets', 4, 50, 'set', 'Low in Stock', 'active'),
(24, 'CLOSED COIL SPRING', 6, 50, 'pcs', 'Low in Stock', 'active'),
(25, 'Coax', 1, 50, 'packs', 'Low in Stock', 'active'),
(26, 'Composite A1', 1, 50, 'pcs', 'Out of Stock', 'active'),
(27, 'Composite A2', 3, 50, 'pcs', 'Low in Stock', 'active'),
(28, 'Composite A3', 3, 50, 'pcs', 'Low in Stock', 'active'),
(29, 'Composite A3.5', 4, 50, 'pcs', 'Low in Stock', 'active'),
(30, 'Composite A30', 1, 50, 'pcs', 'Good', 'active'),
(31, 'Composite B2', 2, 50, 'pcs', 'Low in Stock', 'active'),
(32, 'Composite Bonding Agent', 1, 50, 'pcs', 'Low in Stock', 'active'),
(33, 'Composite instruments code-05703', 1, 50, 'pcs', 'Low in Stock', 'active'),
(34, 'Composite instruments code-05707', 1, 50, 'pcs', 'Low in Stock', 'active'),
(35, 'composite Inc.', 11, 50, 'pcs', 'Low in Stock', 'active'),
(36, 'CuNiTi .016 Lower', 1, 50, 'pcs', 'Low in Stock', 'active'),
(37, 'CuNiTi .12 Upper', 1, 50, 'pcs', 'Low in Stock', 'active'),
(38, 'Defoger', 4, 50, 'pcs', 'Low in Stock', 'active'),
(39, 'Dental Impression material tray', 85, 50, 'pcs', 'Low in Stock', 'active'),
(40, 'Diestone', 0, 50, 'pcs', 'Out of Stock', 'active'),
(41, 'Disposable Syringes 10cc', 50, 50, 'pcs', 'Low in Stock', 'active'),
(42, 'Dowel Posts Large', 4, 50, 'pcs', 'Low in Stock', 'active'),
(43, 'Dowel Posts Medium', 4, 50, 'pcs', 'Low in Stock', 'active'),
(44, 'Dowel Posts Short', 4, 50, 'pcs', 'Low in Stock', 'active'),
(45, 'DRIVER', 1, 50, 'pcs', 'Low in Stock', 'active'),
(46, 'Dycal', 2, 50, 'Pair', 'Good', 'active'),
(47, 'Elastic Chain', 20, 50, 'pcs', 'Low in Stock', 'active'),
(48, 'Endo Block', 1, 50, 'pcs', 'Low in Stock', 'active'),
(49, 'Etchant', 1, 50, 'pcs', 'Low in Stock', 'active'),
(50, 'EX 12', 7, 50, 'pcs', 'Good', 'active'),
(51, 'Expander Keys', 13, 50, 'pcs', 'Good', 'active'),
(52, 'Face Masks', 14, 50, 'Boxes', 'Good', 'active'),
(53, 'Fermine', 1, 50, 'Bottles', 'Low in Stock', 'active'),
(54, 'Fishbone Trrays', 2, 50, 'pcs', 'Low in Stock', 'active'),
(55, 'Fissure Burs', 37, 50, 'pcs', 'Good', 'active'),
(56, 'Flouride Gel', 38, 50, 'pcs', 'Good', 'active'),
(57, 'Flowable Composite A2', 1, 50, 'pcs', 'Low in Stock', 'active'),
(58, 'Flowable Composite A3', 0, 50, 'pcs', 'Out of Stock', 'active'),
(59, 'Flowable Composite A3.5', 0, 50, 'pcs', 'Out of Stock', 'active'),
(60, 'Forestadent wire LOWER .012', 4, 50, 'pcs', 'Low in Stock', 'active'),
(61, 'Forestadent wire UPER .012', 5, 50, 'pcs', 'Low in Stock', 'active'),
(62, 'Formocresol', 1, 50, 'pcs', 'Low in Stock', 'active'),
(63, 'gauze', 0, 50, 'pcs', 'Out of Stock', 'active'),
(64, 'Gingi Master', 1, 50, 'pcs', 'Low in Stock', 'active'),
(65, 'Gingi Master Refill', 6, 50, 'pcs', 'Low in Stock', 'active'),
(66, 'Glass Ionomer Cement GIC', 0, 50, 'Boxes', 'Out of Stock', 'active'),
(67, 'GLOVES LARGE', 22, 50, 'Boxes', 'Good', 'active'),
(68, 'GLOVES SMALL', 8, 50, 'Boxes', 'Good', 'active'),
(69, 'Goring', 10, 50, 'Boxes', 'Good', 'active'),
(70, 'GS II FIXTURE', 1, 50, 'pcs', 'Low in Stock', 'active'),
(71, 'Gun type w/ temp crown', 1, 50, 'Set', 'Low in Stock', 'active'),
(72, 'Gutta Percha 15-40', 0, 50, 'pcs', 'Out of Stock', 'active'),
(73, 'Gutta Percha 45-80', 6, 50, 'Packs', 'Low in Stock', 'active'),
(74, 'HANDPIECE HIGHSPEED / yabangbang', 0, 50, 'pcs', 'Out of Stock', 'active'),
(75, 'HANDPIECE NSK DYNALED/SURGERY', 0, 50, 'Packs', 'Out of Stock', 'active'),
(76, 'HANDPIECE NSK PANAMAX', 0, 50, 'pcs', 'Out of Stock', 'active'),
(77, 'HANDPIECE SET serial # 100300503', 2, 50, 'set', 'Low in Stock', 'active'),
(78, 'HANDPIECE SET serial # 1100300503', 0, 50, 'set', 'Out of Stock', 'active'),
(79, 'HANDPIECE SINGLE SET # 0074693', 0, 50, 'pcs', 'Out of Stock', 'active'),
(80, 'HANDPIECE SINGLE SET # 0074694', 0, 50, 'pcs', 'Out of Stock', 'active'),
(81, 'HANDPIECE SINGLE SET # 0074695', 0, 50, 'pcs', 'Out of Stock', 'active'),
(82, 'HANDPIECE SINGLE SET # 0074696', 0, 50, 'pcs', 'Out of Stock', 'active'),
(83, 'HANPIECE LUBRICANT', 0, 50, 'pcs', 'Out of Stock', 'active'),
(84, 'HANDPIECE SINGLE SET # 0866090', 0, 50, 'pcs', 'Out of Stock', 'active'),
(85, 'Hemodent', 1, 50, 'Bottles', 'Low in Stock', 'active'),
(86, 'H-FILE 015-040', 3, 50, 'pcs', 'Low in Stock', 'active'),
(87, 'IRM', 0, 50, 'pcs', 'Out of Stock', 'active'),
(88, 'K-Files #10 21mm', 11, 50, 'pcs', 'Good', 'active'),
(89, 'Ligatice', 167, 50, 'pcs', 'Good', 'active'),
(90, 'Ligature wire', 0, 50, 'pcs', 'Out of Stock', 'active'),
(91, 'LIIDOCAINE hcl', 0, 50, 'pcs', 'Out of Stock', 'active'),
(92, 'Luminous Dappen Dish', 12, 50, 'pcs', 'Good', 'active'),
(93, 'Matrix band universal', 18, 50, 'pcs', 'Good', 'active'),
(94, 'METAPEX', 1, 50, 'pcs', 'Low in Stock', 'active'),
(95, 'Mixing Pad Big', 3, 50, 'pcs', 'Low in Stock', 'active'),
(96, 'Mixing Pad Small', 0, 50, 'pcs', 'Out of Stock', 'active'),
(97, 'Modeling compound', 0, 50, 'pcs', 'Out of Stock', 'active'),
(98, 'Molar bands', 72, 50, 'pcs', 'Good', 'active'),
(99, 'NiTi .012 lower', 8, 50, 'pcs', 'Good', 'active'),
(100, 'NiTi .012 upper', 9, 50, 'pcs', 'Good', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(32, '2014_10_12_000000_create_users_table', 1),
(33, '2014_10_12_100000_create_password_resets_table', 1),
(34, '2018_03_14_074254_create_patients_table', 1),
(35, '2018_03_15_130305_create_inventories_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patID` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patientTelNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthDate` date NOT NULL,
  `age` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `medconditions` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'None',
  `allergies` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'None',
  `balance` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `patStatus` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patID`, `name`, `address`, `occupation`, `patientTelNo`, `status`, `birthDate`, `age`, `sex`, `medconditions`, `allergies`, `balance`, `patStatus`, `created_at`, `updated_at`) VALUES
(1, 'Gandeza Rachel E', 'Marville Subdivision Irisan Baguio City', 'Student', '9260717250', 'Single', '0000-00-00', '24', 'F', '', '', '0', 'active', NULL, NULL),
(2, 'Maria Olivia Margaris', 'Marville Subdivision Baguio City', 'Security Guard', '9193279345', 'Married', '0000-00-00', '35', 'F', '', '', '0', 'active', NULL, NULL),
(3, 'Di Anne P Monreal', 'Bakakeng Sur Baguio City', 'Cabin Crew', '9173024102', 'Single', '1988-12-28', '26', 'F', 'None', 'None', '0', 'Active', NULL, '2018-03-18 03:25:19'),
(4, 'Jesssie G. Bautista', 'Honeymonon RD Baguio City', 'Maintenance', '9302184788', 'Married', '0000-00-00', '27', 'M', '', '', '0', 'active', NULL, NULL),
(5, 'Joan Polomen', '5 Assumption Corner Session road', 'Student', '9282817870', 'Married', '1987-09-06', '34', 'F', 'None', 'None', '0', 'active', NULL, '2018-03-18 04:00:14'),
(6, 'Jhoairha Manaiang', '68 Mabini corner Gen. Luna', 'Civil Engineer', '9653265299', 'Single', '0000-00-00', '17', 'M', 'None', 'None', '0', 'active', NULL, '2018-03-18 04:01:02'),
(7, 'Magilyn Lim', '7 Laubach Road Baguio City', 'Flight Attendant', '9277948873', 'Married', '0000-00-00', '40', 'F', '', '', '0', 'active', NULL, NULL),
(8, 'Kailey Robyn C. Bernal', '129E Leonila Mill', 'Student', '9778560101', 'Single', '0000-00-00', '8', 'F', '', '', '0', 'active', NULL, NULL),
(9, 'Rexelle Jun R. Bersamin', 'North Cambridge Condominium Bakakeng Baguio City', 'Security Guard', '9269350953', 'Single', '0000-00-00', '23', 'M', '', '', '0', 'active', NULL, NULL),
(11, 'Jay Testado', '55 Simisimi Compound Ambuclao Rd. Pacdal Baguio City', 'Dentist', '09586056545', 'Single', '1997-07-05', '20', 'M', 'None', 'None', '0', 'Active', '2018-03-17 22:24:09', '2018-03-18 03:58:52');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payID` int(11) NOT NULL,
  `datePaid` date NOT NULL,
  `amount` int(11) NOT NULL,
  `receive` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `recordID` int(11) NOT NULL,
  `dentist` varchar(45) NOT NULL,
  `servPeformed` varchar(45) NOT NULL,
  `patient` varchar(45) NOT NULL,
  `payment` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `schedID` int(11) NOT NULL,
  `scheduledDate` date NOT NULL,
  `timeFrom` time NOT NULL,
  `timeTo` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `serperinventory`
--

CREATE TABLE `serperinventory` (
  `invQty` int(11) NOT NULL,
  `service` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `servID` int(11) NOT NULL,
  `servname` varchar(45) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `serviceschedule`
--

CREATE TABLE `serviceschedule` (
  `serPref` int(11) NOT NULL,
  `schedDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Jay', 'jay@test.com', '$2y$10$E1hb98SLMaLidfZZ3bl0D.FtTqTWvuaeTLVaoMDNi2aoPeDOdaUUG', NULL, '2018-03-18 02:08:28', '2018-03-18 02:08:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`apptID`),
  ADD UNIQUE KEY `apptID_UNIQUE` (`apptID`),
  ADD UNIQUE KEY `services_UNIQUE` (`services`);

--
-- Indexes for table `dental_clinic_assistant`
--
ALTER TABLE `dental_clinic_assistant`
  ADD PRIMARY KEY (`asstID`),
  ADD UNIQUE KEY `asstID_UNIQUE` (`asstID`);

--
-- Indexes for table `dentist`
--
ALTER TABLE `dentist`
  ADD PRIMARY KEY (`dentID`),
  ADD UNIQUE KEY `dentID_UNIQUE` (`dentID`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`histID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`invID`),
  ADD KEY `inventory_invid_index` (`invID`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payID`),
  ADD UNIQUE KEY `payID_UNIQUE` (`payID`);

--
-- Indexes for table `record`
--
ALTER TABLE `record`
  ADD PRIMARY KEY (`recordID`),
  ADD UNIQUE KEY `recordID_UNIQUE` (`recordID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`schedID`),
  ADD UNIQUE KEY `schedID_UNIQUE` (`schedID`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`servID`),
  ADD UNIQUE KEY `servID_UNIQUE` (`servID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `apptID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dental_clinic_assistant`
--
ALTER TABLE `dental_clinic_assistant`
  MODIFY `asstID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dentist`
--
ALTER TABLE `dentist`
  MODIFY `dentID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `histID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `invID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `record`
--
ALTER TABLE `record`
  MODIFY `recordID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `schedID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `servID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
