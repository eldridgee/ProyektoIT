<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=1,initial-scale=1,user-scalable=1" />
	<title><?php echo e(config('app.name', 'Gabriana DCMS')); ?></title>

	<link href="<?php echo e(asset('design/login/assets/bootstrap/css/font.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('design/login/assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"  />
	<link href="<?php echo e(asset('design/login/assets/css/styles.css')); ?>" rel="stylesheet" type="text/css"  />
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo e(asset('design/login/assets/bootstrap/js/html5shiv.min.js')); ?>"></script>
      <script src="<?php echo e(asset('design/login/assets/bootstrap/js/respond.min.js')); ?>"></script>
    <![endif]-->
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('design/login/assets/bootstrap/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('design/login/assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
</body>
</html>