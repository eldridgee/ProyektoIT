@extends('layouts.adminLayout')

@section('content')

    {!! Form::open(['action' => 'PatientsController@store' , 'method' => 'POST']) !!}
        
    {!! Form::close() !!}

@endsection