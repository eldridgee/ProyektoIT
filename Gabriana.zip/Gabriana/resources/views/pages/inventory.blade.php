@extends('layouts.adminLayout')

@section('content')
<div class="wrapper">
  <!-- Left side column. contains the logo and sidebar -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Tables
      </h1>
      <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Inventory</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Inventory ID</th>
                  <th>Name</th>
                  <th>Quantity</th>
                  <th>Unit</th>
                  <th>Inventory Status</th>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody>
                  @if(count($inventory) > 1)
                    @foreach($inventory as $item)
                    <tr>
                      <td>{{$item->id}}</td>
                      <td>{{$item->name}}</td>
                      <td>{{$item->quantity}}</td>
                      <td>{{$item->unit}}</td>
                      <td>{{$item->inv_status}}</td>
                      <td>{{$item->status}}</td>
                    </tr>
                    @endforeach
                  @else
                    <p>No posts found</p>
                  @endif
                </tbody>
                <tfoot>
                <tr>
                  <th>Inventory ID</th>
                  <th>Name</th>
                  <th>Quantity</th>
                  <th>Unit</th>
                  <th>Inventory Status</th>
                  <th>Status</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <aside class="control-sidebar control-sidebar-dark">

      <!-- Tab panes -->
      <div class="tab-content">
          <!-- Home tab content -->
          <div class="tab-pane" id="control-sidebar-home-tab">
              <!-- /.control-sidebar-menu -->
              <h3 class="control-sidebar-heading">Tasks Progress</h3>
              <ul class="control-sidebar-menu">
                  <li>
                      <a href="javascript:void(0)">
                          <h4 class="control-sidebar-subheading">
                              Custom Template Design
                              <span class="label label-danger pull-right">70%</span>
                          </h4>
                          <div class="progress progress-xxs">
                              <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
                          </div>
                      </a>
                  </li>
                  <li>
                      <a href="javascript:void(0)">
                          <h4 class="control-sidebar-subheading">
                              Update Resume
                              <span class="label label-success pull-right">95%</span>
                          </h4>
                          <div class="progress progress-xxs">
                              <div class="progress-bar progress-bar-success" style="width: 95%"></div>
                          </div>
                      </a>
                  </li>
                  <li>
                      <a href="javascript:void(0)">
                          <h4 class="control-sidebar-subheading">
                              Laravel Integration
                              <span class="label label-warning pull-right">50%</span>
                          </h4>
                          <div class="progress progress-xxs">
                              <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
                          </div>
                      </a>
                  </li>
                  <li>
                      <a href="javascript:void(0)">
                          <h4 class="control-sidebar-subheading">
                              Back End Framework
                              <span class="label label-primary pull-right">68%</span>
                          </h4>
                          <div class="progress progress-xxs">
                              <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
                          </div>
                      </a>
                  </li>
              </ul>
              <!-- /.control-sidebar-menu -->
          </div>
          <!-- /.tab-pane -->
          <!-- Stats tab content -->
          <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
          <!-- /.tab-pane -->
          <!-- Settings tab content -->
          <div class="tab-pane" id="control-sidebar-settings-tab">
              <form method="post">
                  <h3 class="control-sidebar-heading">General Settings</h3>
                  <div class="form-group">
                      <label class="control-sidebar-subheading">
                      Report panel usage
                      <input type="checkbox" class="pull-right" checked>
                      </label>
                      <p>
                          Some information about this general settings option
                      </p>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                      <label class="control-sidebar-subheading">
                      Allow mail redirect
                      <input type="checkbox" class="pull-right" checked>
                      </label>
                      <p>
                          Other sets of options are available
                      </p>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                      <label class="control-sidebar-subheading">
                      Expose author name in posts
                      <input type="checkbox" class="pull-right" checked>
                      </label>
                      <p>
                          Allow the user to show his name in blog posts
                      </p>
                  </div>
                  <!-- /.form-group -->
                  <h3 class="control-sidebar-heading">Chat Settings</h3>
                  <div class="form-group">
                      <label class="control-sidebar-subheading">
                      Show me as online
                      <input type="checkbox" class="pull-right" checked>
                      </label>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                      <label class="control-sidebar-subheading">
                      Turn off notifications
                      <input type="checkbox" class="pull-right">
                      </label>
                  </div>
                  <!-- /.form-group -->
                  <div class="form-group">
                      <label class="control-sidebar-subheading">
                      Delete chat history
                      <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
                      </label>
                  </div>
                  <!-- /.form-group -->
              </form>
          </div>
          <!-- /.tab-pane -->
      </div>
    </aside>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


  @endsection

