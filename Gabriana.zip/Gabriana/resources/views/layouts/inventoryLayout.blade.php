<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ config('app.name', 'Gabriana DCMS') }}</title>

    <link href="{{ asset('design/datatable/css/datatables.bootstrap.css') }}" rel="stylesheet">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="{{ asset('design/datatable/css/bootstrap.min.css') }}" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

</head>
<body>
    @yield('content')
    @include('inc.nav')
    <script src="{{ asset('design/datatable/js/jquery.min.js') }}"></script>
    <script src="{{ asset('design/datatable/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('design/datatable/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('design/datatable/js/datatables.bootstrap.js') }}"></script>
</body>
</html>