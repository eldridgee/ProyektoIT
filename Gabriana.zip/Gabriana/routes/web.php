<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('pages.welcome');
});

Route::get('/admin', function () {
    return view('pages.admin');
});

Route::get('/admin2', function () {
    return view('pages.admin2');
});

Route::get('/top-nav', function () {
    return view('nav.top-nav');
});

Route::get('/collapsed-sidebar', function () {
    return view('nav.collapsed-sidebar');
});

Route::get('/fixed', function () {
    return view('nav.fixed');
});

Route::get('/boxed', function () {
    return view('nav.boxed');
});

Route::get('/try', function () {
    return view('pages.try');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
