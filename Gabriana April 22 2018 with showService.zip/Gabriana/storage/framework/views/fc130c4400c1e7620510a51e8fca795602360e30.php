<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Show Service Information
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class=""><a href="<?php echo e(url('/admin/service')); ?>">Services</a></li>
            <li class="active">Show</li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Show Service</h3>
                        </div>
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <th>Service Name</th>
                                            <td><?php echo e($service->servName); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Service Price</th>
                                            <td><?php echo e($service->price); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <a href="<?php echo e(url('/admin/service')); ?>" class="btn btn-default">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>