-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: gab
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment` (
  `apptID` int(11) NOT NULL AUTO_INCREMENT,
  `services` varchar(45) NOT NULL,
  `date` date NOT NULL,
  `invUsed` varchar(45) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `bill` int(11) DEFAULT NULL,
  PRIMARY KEY (`apptID`),
  UNIQUE KEY `apptID_UNIQUE` (`apptID`),
  UNIQUE KEY `services_UNIQUE` (`services`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dental_clinic_assistant`
--

DROP TABLE IF EXISTS `dental_clinic_assistant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dental_clinic_assistant` (
  `asstID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `asstTelNO` varchar(45) NOT NULL,
  PRIMARY KEY (`asstID`),
  UNIQUE KEY `asstID_UNIQUE` (`asstID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dental_clinic_assistant`
--

LOCK TABLES `dental_clinic_assistant` WRITE;
/*!40000 ALTER TABLE `dental_clinic_assistant` DISABLE KEYS */;
/*!40000 ALTER TABLE `dental_clinic_assistant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dentist`
--

DROP TABLE IF EXISTS `dentist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dentist` (
  `dentID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `dentTelNo` varchar(45) NOT NULL,
  PRIMARY KEY (`dentID`),
  UNIQUE KEY `dentID_UNIQUE` (`dentID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dentist`
--

LOCK TABLES `dentist` WRITE;
/*!40000 ALTER TABLE `dentist` DISABLE KEYS */;
INSERT INTO `dentist` VALUES (1,'Alberto Tiolenco','09063529898'),(2,'Keon Tamayo','09362559876'),(3,'Mrs. G','09966968696'),(4,'Mr. Gabibe','09699969696');
/*!40000 ALTER TABLE `dentist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dentistservices`
--

DROP TABLE IF EXISTS `dentistservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dentistservices` (
  `serPerformed` int(11) NOT NULL,
  `dentAssigned` varchar(45) NOT NULL,
  `timePerformed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `servDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dentistservices`
--

LOCK TABLES `dentistservices` WRITE;
/*!40000 ALTER TABLE `dentistservices` DISABLE KEYS */;
/*!40000 ALTER TABLE `dentistservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `histID` int(11) NOT NULL AUTO_INCREMENT,
  `dateAdded` date DEFAULT NULL,
  `timeAdded` varchar(45) DEFAULT NULL,
  `invAdded` int(11) DEFAULT NULL,
  `qtyUnused` int(11) DEFAULT NULL,
  PRIMARY KEY (`histID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `invID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `low_stock_quantity` int(11) NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invStatus` enum('Out of Stock','Low in Stock','Good') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`invID`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'2 To 4 HOLES ADAPTER',5,50,'pcs','Low in Stock','Active',NULL,NULL),(2,'4 TO TO',1,50,'pcs','Low in Stock','Active',NULL,NULL),(3,'Alginate/Kromopan',11,50,'kilos','Low in Stock','Active',NULL,NULL),(4,'Anesthesia',10,50,'pcs','Low in Stock','Active',NULL,NULL),(5,'Applicator tips',4,50,'pcs','','Active',NULL,NULL),(6,'Articulating Paper',21,50,'pcs','Low in Stock','Active',NULL,NULL),(7,'Barbed Roach',8,50,'pcs','','Active',NULL,NULL),(8,'BEAUTI-CEMENT',1,50,'pcs','Low in Stock','Active',NULL,NULL),(9,'big diamonds finishing burr',1,50,'pcs','Low in Stock','Active',NULL,NULL),(10,'Bite Block',8,50,'pcs','Low in Stock','Active',NULL,NULL),(11,'Bite Wax',37,50,'pcs','Low in Stock','Active',NULL,NULL),(12,'Bone Burrs',6,50,'pcs','Low in Stock','Active',NULL,NULL),(13,'BONDING agent',1,50,'pcs','Low in Stock','Active',NULL,NULL),(14,'Brackets',26,50,'set','Low in Stock','Active',NULL,NULL),(15,'Buccal Tubes',0,50,'set','Out of Stock','Inactive',NULL,NULL),(16,'Burr -40 round',2,50,'pcs','Low in Stock','Active',NULL,NULL),(17,'Burrs # 368016',3,50,'pcs','Low in Stock','Active',NULL,NULL),(18,'Burrs diamond point (FG)',5,50,'pcs','Low in Stock','Active',NULL,NULL),(19,'Calibra esthetic Resin Cement',3,50,'pcs','Low in Stock','Active',NULL,NULL),(20,'Castone',12,50,'pcs','Low in Stock','Active',NULL,NULL),(21,'Cavitron',1,50,'pcs','Low in Stock','Active',NULL,NULL),(22,'Celluloid Strip',4,50,'pcs','Low in Stock','Active',NULL,NULL),(23,'Ceramic Brackets',4,50,'set','Low in Stock','Active',NULL,NULL),(24,'CLOSED COIL SPRING',6,50,'pcs','Low in Stock','Active',NULL,NULL),(25,'Coax',1,50,'packs','Low in Stock','Active',NULL,NULL),(26,'Composite A1',1,50,'pcs','Out of Stock','Active',NULL,NULL),(27,'Composite A2',3,50,'pcs','Low in Stock','Active',NULL,NULL),(28,'Composite A3',3,50,'pcs','Low in Stock','Active',NULL,NULL),(29,'Composite A3.5',4,50,'pcs','Low in Stock','Active',NULL,NULL),(30,'Composite A30',1,50,'pcs','','Active',NULL,NULL),(31,'Composite B2',2,50,'pcs','Low in Stock','Active',NULL,NULL),(32,'Composite Bonding Agent',1,50,'pcs','Low in Stock','Active',NULL,NULL),(33,'Composite instruments code-05703',1,50,'pcs','Low in Stock','Active',NULL,NULL),(34,'Composite instruments code-05707',1,50,'pcs','Low in Stock','Active',NULL,NULL),(35,'composite Inc.',11,50,'pcs','Low in Stock','Active',NULL,NULL),(36,'CuNiTi .016 Lower',1,50,'pcs','Low in Stock','Active',NULL,NULL),(37,'CuNiTi .12 Upper',1,50,'pcs','Low in Stock','Active',NULL,NULL),(38,'Defoger',4,50,'pcs','Low in Stock','Active',NULL,NULL),(39,'Dental Impression material tray',85,50,'pcs','Low in Stock','Active',NULL,NULL),(40,'Diestone',0,50,'pcs','Out of Stock','Active',NULL,NULL),(41,'Disposable Syringes 10cc',50,50,'pcs','Low in Stock','Active',NULL,NULL),(42,'Dowel Posts Large',4,50,'pcs','Low in Stock','Active',NULL,NULL),(43,'Dowel Posts Medium',4,50,'pcs','Low in Stock','Active',NULL,NULL),(44,'Dowel Posts Short',4,50,'pcs','Low in Stock','Active',NULL,NULL),(45,'DRIVER',1,50,'pcs','Low in Stock','Active',NULL,NULL),(46,'Dycal',2,50,'Pair','','Active',NULL,NULL),(47,'Elastic Chain',20,50,'pcs','Low in Stock','Active',NULL,NULL),(48,'Endo Block',1,50,'pcs','Low in Stock','Active',NULL,NULL),(49,'Etchant',1,50,'pcs','Low in Stock','Active',NULL,NULL),(50,'EX 12',7,50,'pcs','','Active',NULL,NULL),(51,'Expander Keys',13,50,'pcs','','Active',NULL,NULL),(52,'Face Masks',14,50,'Boxes','','Active',NULL,NULL),(53,'Fermine',1,50,'Bottles','Low in Stock','Active',NULL,NULL),(54,'Fishbone Trrays',2,50,'pcs','Low in Stock','Active',NULL,NULL),(55,'Fissure Burs',37,50,'pcs','','Active',NULL,NULL),(56,'Flouride Gel',38,50,'pcs','','Active',NULL,NULL),(57,'Flowable Composite A2',1,50,'pcs','Low in Stock','Active',NULL,NULL),(58,'Flowable Composite A3',0,50,'pcs','Out of Stock','Active',NULL,NULL),(59,'Flowable Composite A3.5',0,50,'pcs','Out of Stock','Active',NULL,NULL),(60,'Forestadent wire LOWER .012',4,50,'pcs','Low in Stock','Active',NULL,NULL),(61,'Forestadent wire UPER .012',5,50,'pcs','Low in Stock','Active',NULL,NULL),(62,'Formocresol',1,50,'pcs','Low in Stock','Active',NULL,NULL),(63,'gauze',0,50,'pcs','Out of Stock','Active',NULL,NULL),(64,'Gingi Master',1,50,'pcs','Low in Stock','Active',NULL,NULL),(65,'Gingi Master Refill',6,50,'pcs','Low in Stock','Active',NULL,NULL),(66,'Glass Ionomer Cement GIC',0,50,'Boxes','Out of Stock','Active',NULL,NULL),(67,'GLOVES LARGE',22,50,'Boxes','','Active',NULL,NULL),(68,'GLOVES SMALL',8,50,'Boxes','','Active',NULL,NULL),(69,'Goring',10,50,'Boxes','','Active',NULL,NULL),(70,'GS II FIXTURE',1,50,'pcs','Low in Stock','Active',NULL,NULL),(71,'Gun type w/ temp crown',1,50,'Set','Low in Stock','Active',NULL,NULL),(72,'Gutta Percha 15-40',0,50,'pcs','Out of Stock','Active',NULL,NULL),(73,'Gutta Percha 45-80',6,50,'Packs','Low in Stock','Active',NULL,NULL),(74,'HANDPIECE HIGHSPEED / yabangbang',0,50,'pcs','Out of Stock','Active',NULL,NULL),(75,'HANDPIECE NSK DYNALED/SURGERY',0,50,'Packs','Out of Stock','Active',NULL,NULL),(76,'HANDPIECE NSK PANAMAX',0,50,'pcs','Out of Stock','Active',NULL,NULL),(77,'HANDPIECE SET serial # 100300503',2,50,'set','Low in Stock','Active',NULL,NULL),(78,'HANDPIECE SET serial # 1100300503',0,50,'set','Out of Stock','Active',NULL,NULL),(79,'HANDPIECE SINGLE SET # 0074693',0,50,'pcs','Out of Stock','Active',NULL,NULL),(80,'HANDPIECE SINGLE SET # 0074694',0,50,'pcs','Out of Stock','Active',NULL,NULL),(81,'HANDPIECE SINGLE SET # 0074695',0,50,'pcs','Out of Stock','Active',NULL,NULL),(82,'HANDPIECE SINGLE SET # 0074696',0,50,'pcs','Out of Stock','Active',NULL,NULL),(83,'HANPIECE LUBRICANT',0,50,'pcs','Out of Stock','Active',NULL,NULL),(84,'HANDPIECE SINGLE SET # 0866090',0,50,'pcs','Out of Stock','Active',NULL,NULL),(85,'Hemodent',1,50,'Bottles','Low in Stock','Active',NULL,NULL),(86,'H-FILE 015-040',3,50,'pcs','Low in Stock','Active',NULL,NULL),(87,'IRM',0,50,'pcs','Out of Stock','Active',NULL,NULL),(88,'K-Files #10 21mm',11,50,'pcs','','Active',NULL,NULL),(89,'Ligatice',167,50,'pcs','','Active',NULL,NULL),(90,'Ligature wire',0,50,'pcs','Out of Stock','Active',NULL,NULL),(91,'LIIDOCAINE hcl',0,50,'pcs','Out of Stock','Active',NULL,NULL),(92,'Luminous Dappen Dish',12,50,'pcs','','Active',NULL,NULL),(93,'Matrix band universal',18,50,'pcs','','Active',NULL,NULL),(94,'METAPEX',1,50,'pcs','Low in Stock','Active',NULL,NULL),(95,'Mixing Pad Big',3,50,'pcs','Low in Stock','Active',NULL,NULL),(96,'Mixing Pad Small',0,50,'pcs','Out of Stock','Active',NULL,NULL),(97,'Modeling compound',0,50,'pcs','Out of Stock','Active',NULL,NULL),(98,'Molar bands',72,50,'pcs','','Active',NULL,NULL),(99,'NiTi .012 Lower',8,50,'pcs','','Active',NULL,NULL),(100,'NiTi .012 Upper',9,50,'pcs','','Active',NULL,NULL),(101,'NiTi .014 Lower',0,50,'pcs','Out of Stock','Active',NULL,NULL),(102,'NiTi .014 Upper',4,50,'pcs','Low in Stock','Active',NULL,NULL),(103,'NiTi .016 Lower',10,50,'pcs','','Active',NULL,NULL),(104,'NiTi .016 Upper',12,50,'pcs','','Active',NULL,NULL),(105,'NiTi .017*022 Lower',19,50,'pcs','','Active',NULL,NULL),(106,'NiTi .017*022 Upper',8,50,'pcs','','Active',NULL,NULL),(107,'NiTi .017*025 Lower',11,50,'pcs','','Active',NULL,NULL),(108,'NiTi .017*025 Upper',13,50,'pcs','','Active',NULL,NULL),(109,'NiTi .018 Lower',14,50,'pcs','','Active',NULL,NULL),(110,'NiTi .018 Upper',23,50,'pcs','','Active',NULL,NULL),(111,'NiTi .019x.025 Upper',3,50,'pcs','Low in Stock','Active',NULL,NULL),(112,'NiTi .021x025 Lower',10,50,'pcs','','Active',NULL,NULL),(113,'NiTi .16 x 22 Lower',3,50,'pcs','Low in Stock','Active',NULL,NULL),(114,'NiTi .16 x 22 Upper',5,50,'pcs','Low in Stock','Active',NULL,NULL),(115,'Op brush tips',2,50,'Boxes','Low in Stock','Active',NULL,NULL),(116,'Open coil spring',0,50,'pcs','Out of Stock','Active',NULL,NULL),(117,'Oral B superfloss',11,50,'Boxes','','Active',NULL,NULL),(118,'Ortho bonding Agent',1,50,'pcs','Low in Stock','Active',NULL,NULL),(119,'Ortho cement',0,50,'pcs','Out of Stock','Active',NULL,NULL),(120,'Ortho elastics 1/4 Heavy',11,50,'Packs','','Active',NULL,NULL),(121,'Ortho elastics 1/4 Light',8,50,'Packs','','Active',NULL,NULL),(122,'Ortho elastics 1/4 Medium',6,50,'Packs','','Active',NULL,NULL),(123,'Ortho elastics 1/8 Heavy',27,50,'Packs','','Active',NULL,NULL),(124,'Ortho elastics 1/8 Light',0,50,'Packs','Out of Stock','Active',NULL,NULL),(125,'Ortho elastics 1/8 Medium',9,50,'Packs','','Active',NULL,NULL),(126,'Ortho elastics 3/16 Heavy',21,50,'Packs','','Active',NULL,NULL),(127,'Ortho elastics 3/16 Light',10,50,'Packs','','Active',NULL,NULL),(128,'Ortho elastics 3/16 Medium',6,50,'Packs','','Active',NULL,NULL),(129,'Ortho elastics 5/16 Heavy',18,50,'Packs','','Active',NULL,NULL),(130,'Ortho elastics 5/16 Light',8,50,'Packs','','Active',NULL,NULL),(131,'Ortho elastics 5/16 Medium',19,50,'Packs','','Active',NULL,NULL),(132,'Ortho kit',3,50,'Packs','Low in Stock','Active',NULL,NULL),(133,'Ortho wax',6,50,'pcs','','Active',NULL,NULL),(134,'Ostem Implant Kit',0,50,'boxes','Out of Stock','Active',NULL,NULL),(135,'Paper points 15-40',3,50,'Packs','Low in Stock','Active',NULL,NULL),(136,'Paper points 45-80',5,50,'Packs','Low in Stock','Active',NULL,NULL),(137,'Paracore set',1,50,'set','','Active',NULL,NULL),(138,'Plastic Vyneers',4,50,'Packs','Low in Stock','Active',NULL,NULL),(139,'Polishing burrs',3,50,'pcs','Low in Stock','Active',NULL,NULL),(140,'Polishing Strips',3,50,'set','Low in Stock','Active',NULL,NULL),(141,'Polybib',5,50,'Packs','Low in Stock','Active',NULL,NULL),(142,'Primer',2,50,'pcs','Low in Stock','Active',NULL,NULL),(143,'Pumice',1,50,'Bottles','Low in Stock','Active',NULL,NULL),(144,'Rigid abutment',1,50,'pcs','Low in Stock','Active',NULL,NULL),(145,'Round burrs',18,50,'pcs','','Active',NULL,NULL),(146,'Saline Solution',0,50,'pcs','Out of Stock','Active',NULL,NULL),(147,'Saliva Ejector tips',3,50,'Packs','Low in Stock','Active',NULL,NULL),(148,'Scaler ultrasonic insert 25 khz',0,50,'pcs','Out of Stock','Active',NULL,NULL),(149,'Scaler tips 30k denstply',1,50,'pcs','Low in Stock','Active',NULL,NULL),(150,'Screw',1,50,'pcs','Low in Stock','Active',NULL,NULL),(151,'Self curing liquid',1,50,'Bottles','Low in Stock','Active',NULL,NULL),(152,'Self curing powder',5,50,'pcs','Low in Stock','Active',NULL,NULL),(153,'Self ligating 012 lower',10,50,'pcs','','Active',NULL,NULL),(154,'Self ligating 012 upper',10,50,'pcs','','Active',NULL,NULL),(155,'Self ligating brackets metal',0,50,'set','Out of Stock','Active',NULL,NULL),(156,'Self ligating ceramic brackets',1,50,'set','Low in Stock','Active',NULL,NULL),(157,'SF-11',10,50,'pcs','','Active',NULL,NULL),(158,'Sodium chloride',0,50,'pcs','Out of Stock','Active',NULL,NULL),(159,'Splint sheets .020',71,50,'pcs','','Active',NULL,NULL),(160,'Stainless arch .019*025 upper',10,50,'pcs','','Active',NULL,NULL),(161,'Stainless steel .016*022 lower',8,50,'pcs','','Active',NULL,NULL),(162,'Stainless steel .016*022 upper',9,50,'pcs','','Active',NULL,NULL),(163,'Stainless steel .017*022 lower',4,50,'pcs','Low in Stock','Active',NULL,NULL),(164,'Stainless steel .017*022 upper',10,50,'pcs','','Active',NULL,NULL),(165,'Stainless steel 012 lower',0,50,'pcs','Out of Stock','Active',NULL,NULL),(166,'Stainless steel 012 upper',10,50,'pcs','','Active',NULL,NULL),(167,'Stainless steel 014 lower',6,50,'pcs','','Active',NULL,NULL),(168,'Stainless steel 014 upper',13,50,'pcs','','Active',NULL,NULL),(169,'Stainless steel 016 lower',5,50,'pcs','Low in Stock','Active',NULL,NULL),(170,'Stainless steel 016 upper',10,50,'pcs','','Active',NULL,NULL),(171,'Stainless steel 018 lower',17,50,'pcs','','Active',NULL,NULL),(172,'Stainless steel 018 upper',1,50,'pcs','Low in Stock','Active',NULL,NULL),(173,'Stainless steel 020 upper',10,50,'pcs','','Active',NULL,NULL),(174,'Sterilizing pouch large',1,50,'Boxes','Low in Stock','Active',NULL,NULL),(175,'Sterilizing pouch small',180,50,'pcs','','Active',NULL,NULL),(176,'Surgical blade #12',119,50,'pcs','','Active',NULL,NULL),(177,'Surgical blade #15',124,50,'pcs','','Active',NULL,NULL),(178,'Surgical Needle G27 Long',118,50,'pcs','','Active',NULL,NULL),(179,'Surgical Needle G27 Short',219,50,'pcs','','Active',NULL,NULL),(180,'Surgical Needle G30 Short',166,50,'pcs','','Active',NULL,NULL),(181,'Surgical tips',0,50,'pcs','Out of Stock','Active',NULL,NULL),(182,'Suturing needle',35,50,'pcs','','Active',NULL,NULL),(183,'Suturing needle silk 3/0 metric',10,50,'pcs','','Active',NULL,NULL),(184,'Suturing needle silk 4/0 metric',0,50,'pcs','Out of Stock','Active',NULL,NULL),(185,'Syringe (G27 long)',0,50,'pcs','Out of Stock','Active',NULL,NULL),(186,'Sterilization  pouch (5 1/4 x 10\")\"',0,50,'pcs','Out of Stock','Active',NULL,NULL),(187,'Suturing thread',2,50,'Roll','Low in Stock','Active',NULL,NULL),(188,'TF-13',4,50,'pcs','Low in Stock','Active',NULL,NULL),(189,'TF-S41 burrs',9,50,'pcs','','Active',NULL,NULL),(190,'Thermafil Obturation',1,50,'set','Low in Stock','Active',NULL,NULL),(191,'Topical Anesthesia',3,50,'pcs','Low in Stock','Active',NULL,NULL),(192,'TR-11',5,50,'pcs','Low in Stock','Active',NULL,NULL),(193,'TR-13',3,50,'pcs','Low in Stock','Active',NULL,NULL),(194,'Water pick big',4,50,'pcs','','Active',NULL,NULL),(195,'Water pick small',5,50,'pcs','','Active',NULL,NULL),(196,'Transfer Abutment',1,50,'pcs','Low in Stock','Active',NULL,NULL),(197,'Zeta plus',0,50,'pcs','Out of Stock','Active',NULL,NULL),(198,'Zeta ultra disinfectant',0,50,'Bottles','Out of Stock','Active',NULL,NULL);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (113,'2014_10_12_000000_create_users_table',1),(114,'2014_10_12_100000_create_password_resets_table',1),(115,'2018_03_14_074254_create_patients_table',1),(116,'2018_03_18_033440_create_inventories_table',1),(117,'2018_03_22_144428_create_services_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `patID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `patientTelNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthDate` date DEFAULT NULL,
  `age` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sex` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medconditions` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allergies` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `patStatus` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`patID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'Gandeza Rachel E','Marville Subdivision Irisan Baguio City','Student','9260717250','Single','0000-00-00','24','F','','','0','active',NULL,NULL),(2,'Maria Olivia Margaris','Marville Subdivision Baguio City','Security Guard','9193279345','Married','0000-00-00','35','F','','','0','active',NULL,NULL),(3,'Di Anne P Monreal','Bakakeng Sur Baguio City','Cabin Crew','9173024102','Single','0000-00-00','26','F','','','0','active',NULL,NULL),(4,'Jesssie G. Bautista','Honeymonon RD Baguio City','Maintenance','9302184788','Married','0000-00-00','27','M','','','0','active',NULL,NULL),(5,'Joan Polomen','','Student','9282817870','Married','0000-00-00','34','F','','','0','active',NULL,NULL),(6,'Jhoairha Manaiang','','Civil Engineer','9653265299','Single','0000-00-00','17','M','','','0','active',NULL,NULL),(7,'Magilyn Lim','7 Laubach Road Baguio City','Flight Attendant','9277948873','Married','0000-00-00','40','F','','','0','active',NULL,NULL),(8,'Kailey Robyn C. Bernal','129E Leonila Mill','Student','9778560101','Single','0000-00-00','8','F','','','0','active',NULL,NULL),(9,'Rexelle Jun R. Bersamin','North Cambridge Condominium Bakakeng Baguio City','Security Guard','9269350953','Single','0000-00-00','23','M','','','0','active',NULL,NULL),(10,'charice Costales','2A-11 Ledesma St. Aurora Hil Baguio City','HouseWife','244-2461','Married','0000-00-00','29','f','None','None','0','Inactive',NULL,'2018-03-29 13:05:36');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `payID` int(11) NOT NULL AUTO_INCREMENT,
  `datePaid` date NOT NULL,
  `amount` int(11) NOT NULL,
  `receive` varchar(45) NOT NULL,
  PRIMARY KEY (`payID`),
  UNIQUE KEY `payID_UNIQUE` (`payID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `record`
--

DROP TABLE IF EXISTS `record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `record` (
  `recordID` int(11) NOT NULL AUTO_INCREMENT,
  `dentist` varchar(45) NOT NULL,
  `servPeformed` varchar(45) NOT NULL,
  `patient` varchar(45) NOT NULL,
  `payment` int(11) NOT NULL,
  PRIMARY KEY (`recordID`),
  UNIQUE KEY `recordID_UNIQUE` (`recordID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record`
--

LOCK TABLES `record` WRITE;
/*!40000 ALTER TABLE `record` DISABLE KEYS */;
/*!40000 ALTER TABLE `record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `date` date DEFAULT NULL,
  `timeFrom` time DEFAULT NULL,
  `timeTo` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,'2018-03-26 04:11:51','2018-03-26 04:11:51','2018-03-26','12:00:00','13:00:00'),(2,'2018-03-26 07:16:06','2018-03-26 07:16:06','2018-03-26','13:00:00','14:00:00'),(3,'2018-03-28 07:09:48','2018-03-28 07:09:48','2018-03-28','16:00:00','17:00:00');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serperinventory`
--

DROP TABLE IF EXISTS `serperinventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serperinventory` (
  `invQty` int(11) NOT NULL,
  `service` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serperinventory`
--

LOCK TABLES `serperinventory` WRITE;
/*!40000 ALTER TABLE `serperinventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `serperinventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `servID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `servName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`servID`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'Consultation',450,NULL,NULL),(2,'Per-Apical Xray',450,NULL,NULL),(3,'Panoramic Xray',1350,NULL,NULL),(4,'Cephalometric Xray',1350,NULL,NULL),(5,'Oral Prohylaxis/Cleaning(MILD)',650,NULL,NULL),(6,'Oral Prohylaxis/Cleaning(MODERATE)',1000,NULL,NULL),(7,'Oral Prohylaxis/Cleaning(SEVERE)',2000,NULL,NULL),(8,'Composite Fillings (per surface)',750,NULL,NULL),(9,'Pit and fissure sealant',2000,NULL,NULL),(10,'Recementation of crowns',1000,NULL,NULL),(11,'Flouride treatment(Child/Adult)',5000,NULL,NULL),(12,'Temporary filling',750,NULL,NULL),(13,'Flouride varnish',1500,NULL,NULL),(14,'Porcelain Veneers(Zirconia)',25000,NULL,NULL),(15,'Porcelain Veneers(IPS-Emax)',25000,NULL,NULL),(16,'Porcelain Veneers(Adoro)',25000,NULL,NULL),(17,'Teeth whitening',15000,NULL,NULL),(18,'Root Canal(Simple Extraction)',550,NULL,NULL),(19,'Root Canal(Difficult Extraction)',1500,NULL,NULL),(20,'Root Canal(Odontectomy/Impaction)',6500,NULL,NULL),(21,'Implants',60000,NULL,NULL),(22,'Porcelain fused to TI-LITE',9500,NULL,NULL),(23,'Porcelain fused to GOLD',7500,NULL,NULL),(24,'All porcelain crowns (Zirconia)',25000,NULL,NULL),(25,'All porcelain crowns (IPS-emax)',25000,NULL,NULL),(26,'All porcelain crowns (Adoro)',25000,NULL,NULL),(27,'All plastic Biotone (Flexite)',15000,NULL,NULL),(28,'Stayplate-Unilateral-Trubyte(Porcelain)',25000,NULL,NULL),(29,'Stayplate-Unilateral-Naturadent(Porcelain)',20000,NULL,NULL),(30,'CompleteDenture-Ivocap-Injectable(Porcelain)',25000,NULL,NULL),(31,'CompleteDenture-Trubyte-Bioform(Porcelain)',25000,NULL,NULL),(32,'CompleteDenture-Vitanorm(Porcelain)',25000,NULL,NULL),(33,'CompleteDenture-Natura Dent(Porcelain)',25000,NULL,NULL),(34,'CompleteDenture-Vertex-High Impact(Porcelain)',750,NULL,NULL),(35,'CompleteDenture-Biotone(Porcelain)',750,NULL,NULL),(36,'CompleteDenture-Ivoclar(Porcelain)',750,NULL,NULL),(37,'CompleteDenture-Naturatone(Porcelain)',750,NULL,NULL),(38,'CompleteDenture-Denture repair(Porcelain)',750,NULL,NULL),(39,'CompleteDenture-Denture repair w/ impression taking(Porcelain)',1000,NULL,NULL),(40,'CompleteDenture-Denture reline(Porcelain)',750,NULL,NULL),(41,'Retainers-Ordinary',5000,NULL,NULL),(42,'Retainers-Ordinary w/ design',7000,NULL,NULL),(43,'Retainers-Invisible',7000,NULL,NULL),(44,'Retainers-Lingual Retainer',5000,NULL,NULL),(45,'Orthodontic Treatment-Simple',40000,NULL,NULL),(46,'Orthodontic Treatment-Moderate',50000,NULL,NULL),(47,'Orthodontic Treatment-Difficult',60000,NULL,NULL),(48,'Orthodontic Treatment-Ceramic',125000,NULL,NULL),(49,'Orthodontic Treatment-Daemon/Self-ligating',80000,NULL,NULL),(50,'Orthodontic Treatment-Lingual Braces',80000,NULL,NULL),(51,'Orthodontic Treatment-Invisalign',80000,NULL,NULL),(52,'Recementation of fallen brackets, molar bands, buccal tube',550,NULL,NULL),(53,'Replacement of fallen brackets, molar bands, buccal tube',1100,NULL,NULL);
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serviceschedule`
--

DROP TABLE IF EXISTS `serviceschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serviceschedule` (
  `serPref` int(11) NOT NULL,
  `schedDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serviceschedule`
--

LOCK TABLES `serviceschedule` WRITE;
/*!40000 ALTER TABLE `serviceschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `serviceschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Jay','jay@gmail.com','$2y$10$JdmDnq3dbauak.K8S/wgO.F.Ds3d2HDmA1Vnp0Ix/14WR2xj.qwyy','Gqsyu9cAyHavZxaA3OpowbWBuSjTCY8HEpb6ulYINToPqBdTpeGm7PQXbzai','2018-03-29 05:15:35','2018-03-29 05:15:35');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'gab'
--

--
-- Dumping routines for database 'gab'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-03-30  1:27:25
