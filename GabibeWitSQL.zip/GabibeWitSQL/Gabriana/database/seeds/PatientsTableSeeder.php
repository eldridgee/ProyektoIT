<?php

use Illuminate\Database\Seeder;

class PatientsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        // for ($x = 0; $x <= 1000; $x++) {
        //     DB::table('patients')->insert([
        //         'name' => str_random(10),
        //         'address' => str_random(10)
        //     ]);    
        // } 
    
       
    }
}
