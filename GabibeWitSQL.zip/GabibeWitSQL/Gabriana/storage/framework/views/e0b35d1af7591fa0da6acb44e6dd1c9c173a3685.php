<?php $__env->startSection('content'); ?>
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Patient Records
            </h1>
            <hr>
            <a href="<?php echo e(url('/admin/patient/create')); ?>" class= "btn btn-primary">Create Patient</a>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Records</li>
            </ol>
        </section>
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="example1" class="table table-bordered table-hover table-responsive">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Address</th>
                                        <th>Contact No.</th>
                                        <th>Age</th>
                                        <th>Sex</th>
                                        <th>Patient Status</th>
                                        <th style ="width: 25%">Options</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($patients) > 1): ?>
                                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($patient->name); ?></td>
                                                <td><?php echo e($patient->address); ?></td>
                                                <td><?php echo e($patient->patientTelNo); ?></td>
                                                <td><?php echo e($patient->age); ?></td>
                                                <td><?php echo e($patient->sex); ?></td>
                                                <td><?php echo e($patient->patStatus); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('/admin/patient' . '/' . $patient->patID)); ?>" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> Profile</a>
                                                    <a class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> History</a>
                                                    <a class="btn btn-danger btn-xs"><i class="fa fa-trash"></i> Deactivate</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <p>No patients found</p>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
    <!-- /.content -->


  <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>