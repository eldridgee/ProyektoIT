<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Inventory
	</h1>
	<ol class="breadcrumb">
	<li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Inventory</li>
	</ol>
	<hr>
	<a class="btn btn-primary" href="<?php echo e(url('/admin/inventory/create')); ?>" data-modal-id="modal-register">Create new Inventory Item</a>
</section>


<!-- Main content -->
<section class="content">
	<div class="row">
	<div class="col-xs-12">
		<div class="box">
		<!-- /.box-header -->
		<div class="box-body">
			<table id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Name</th>
				<th>Quantity</th>
				<th>Unit</th>
				<th>Inventory Status</th>
				<th>Status</th>
				<th>Options</th>
			</tr>
			</thead>
			<tbody>
				<?php if(count($inventory) > 1): ?>
				<?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($item->invName); ?></td>
					<td><?php echo e($item->quantity); ?></td>
					<td><?php echo e($item->unit); ?></td>
					<td><?php echo e($item->invStatus); ?></td>
					<td><?php echo e($item->status); ?></td>
					<td>
					<center>
						<a href="<?php echo e(url('admin/inventory/' . $item->invID . '/add')); ?>" title="View Schedule"><button class="btn btn-info"><i class="fa fa-plus" aria-hidden="true"></i>  Add</button></a>
						<a href="<?php echo e(url('admin/inventory/' . $item->invID)); ?>" title="View Schedule"><button class="btn btn-info "><i class="fa fa-eye" aria-hidden="true"></i>  View</button></a>
						<a href="<?php echo e(url('admin/inventory/' . $item->invID . '/edit')); ?>" title="Edit Schedule"><button class="btn btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
					</center>					
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
				<p>No Inventory Found</p>
				<?php endif; ?>
			</tbody>
			<tfoot>
			<tr>
				<th>Name</th>
				<th>Quantity</th>
				<th>Unit</th>
				<th>Inventory Status</th>
				<th>Status</th>
				<th>Options</th>
			</tr>
			</tfoot>
			</table>
		</div>
		<!-- /.box-body -->
		</div>
		<!-- /.box -->
	</div>
	<!-- /.col -->
	</div>
	<!-- /.row -->
</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>