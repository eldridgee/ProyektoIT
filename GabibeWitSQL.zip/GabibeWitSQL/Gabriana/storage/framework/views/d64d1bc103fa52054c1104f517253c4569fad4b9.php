<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
                Edit inventory item
            </h1>
            <ol class="breadcrumb">
                <li><a href="/admin"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="">Inventory</li>
                <li class="active">Edit Inventory</li>
            </ol>
        </section>

        <div class="well">
            <?php echo Form::open(['action' => ['InventoryController@update', $inventory->invID], 'method' => 'POST']); ?>

            
            <div class="form-group">
                <?php echo e(Form::label('invName', 'Name')); ?>

                <?php echo e(Form::text('invName', $inventory->invName, ['class' => 'form-control', 'placeholder' => 'Inventory Name'])); ?>

            </div>

            <div class="form-group">
                    <?php echo e(Form::label('quantity', 'Quantity')); ?>

                    <?php echo e(Form::text('quantity', $inventory->quantity, ['class' => 'form-control', 'placeholder' => 'Initial Quantity'])); ?>

            </div>

            <div class="form-group">
                    <?php echo e(Form::label('low_stock_quantity', 'Low Stock Quantity')); ?>

                    <?php echo e(Form::text('low_stock_quantity', $inventory->low_stock_quantity, ['class' => 'form-control', 'placeholder' => 'Enter the Low Stock Quantity'])); ?>

            </div>

            <div class="form-group">
                    <?php echo e(Form::label('unit', 'Unit Category')); ?>

                    <?php echo e(Form::text('unit', $inventory->unit, ['class' => 'form-control', 'placeholder' => 'Enter the Unit category (e.g. Box, Pieces)'])); ?>

            </div>

            
            <?php echo e(Form::hidden('_method', 'PUT')); ?>

            <div class="box-footer">
                <a href="/inventory" class="btn btn-default">Cancel</a>
                <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary pull-right'])); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>