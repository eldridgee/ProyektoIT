<div class="form-group <?php echo e($errors->has('date') ? 'has-error' : ''); ?>">
    <label for="date" class="col-md-4 control-label"><?php echo e('Date'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="date" type="date" id="date" value="<?php echo e(isset($schedule->date) ? $schedule->date : ''); ?>" required>
        <?php echo $errors->first('date', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('timeFrom') ? 'has-error' : ''); ?>">
    <label for="timeFrom" class="col-md-4 control-label"><?php echo e('Timefrom'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="timeFrom" type="time" id="timeFrom" value="<?php echo e(isset($schedule->timeFrom) ? $schedule->timeFrom : ''); ?>" required>
        <?php echo $errors->first('timeFrom', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('timeTo') ? 'has-error' : ''); ?>">
    <label for="timeTo" class="col-md-4 control-label"><?php echo e('Timeto'); ?></label>
    <div class="col-md-6">
        <input class="form-control" name="timeTo" type="time" id="timeTo" value="<?php echo e(isset($schedule->timeTo) ? $schedule->timeTo : ''); ?>" required>
        <?php echo $errors->first('timeTo', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <input class="btn btn-primary" type="submit" value="<?php echo e(isset($submitButtonText) ? $submitButtonText : 'Create'); ?>">
    </div>
</div>
