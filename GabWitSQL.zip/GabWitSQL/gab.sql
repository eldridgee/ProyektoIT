-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: gab
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment` (
  `apptID` int(11) NOT NULL AUTO_INCREMENT,
  `services` varchar(45) NOT NULL,
  `date` date NOT NULL,
  `invUsed` varchar(45) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `bill` int(11) DEFAULT NULL,
  PRIMARY KEY (`apptID`),
  UNIQUE KEY `apptID_UNIQUE` (`apptID`),
  UNIQUE KEY `services_UNIQUE` (`services`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dental_clinic_assistant`
--

DROP TABLE IF EXISTS `dental_clinic_assistant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dental_clinic_assistant` (
  `asstID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `asstTelNO` varchar(45) NOT NULL,
  PRIMARY KEY (`asstID`),
  UNIQUE KEY `asstID_UNIQUE` (`asstID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dental_clinic_assistant`
--

LOCK TABLES `dental_clinic_assistant` WRITE;
/*!40000 ALTER TABLE `dental_clinic_assistant` DISABLE KEYS */;
/*!40000 ALTER TABLE `dental_clinic_assistant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dentist`
--

DROP TABLE IF EXISTS `dentist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dentist` (
  `dentID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `dentTelNo` varchar(45) NOT NULL,
  PRIMARY KEY (`dentID`),
  UNIQUE KEY `dentID_UNIQUE` (`dentID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dentist`
--

LOCK TABLES `dentist` WRITE;
/*!40000 ALTER TABLE `dentist` DISABLE KEYS */;
/*!40000 ALTER TABLE `dentist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dentistservices`
--

DROP TABLE IF EXISTS `dentistservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dentistservices` (
  `serPerformed` int(11) NOT NULL,
  `dentAssigned` varchar(45) NOT NULL,
  `timePerformed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `servDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dentistservices`
--

LOCK TABLES `dentistservices` WRITE;
/*!40000 ALTER TABLE `dentistservices` DISABLE KEYS */;
/*!40000 ALTER TABLE `dentistservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `histID` int(11) NOT NULL AUTO_INCREMENT,
  `dateAdded` date DEFAULT NULL,
  `timeAdded` varchar(45) DEFAULT NULL,
  `invAdded` int(11) DEFAULT NULL,
  `qtyUnused` int(11) DEFAULT NULL,
  PRIMARY KEY (`histID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `invID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `low_stock_quantity` int(11) NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invStatus` enum('Out of Stock','Low in Stock','Good') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`invID`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'2 To 4 HOLES ADAPTER',5,50,'pcs','Low in Stock','Active',NULL,NULL),(2,'4 TO TO',1,50,'pcs','Low in Stock','Active',NULL,NULL),(3,'Alginate/Kromopan',11,50,'kilos','Low in Stock','Active',NULL,NULL),(4,'Anesthesia',10,50,'pcs','Low in Stock','Active',NULL,NULL),(5,'Applicator tips',4,50,'pcs','Good','Active',NULL,NULL),(6,'Articulating Paper',21,50,'pcs','Low in Stock','Active',NULL,NULL),(7,'Barbed Roach',8,50,'pcs','Good','Active',NULL,NULL),(8,'BEAUTI-CEMENT',1,50,'pcs','Low in Stock','Active',NULL,NULL),(9,'big diamonds finishing burr',1,50,'pcs','Low in Stock','Active',NULL,NULL),(10,'Bite Block',8,50,'pcs','Low in Stock','Active',NULL,NULL),(11,'Bite Wax',37,50,'pcs','Low in Stock','Active',NULL,NULL),(12,'Bone Burrs',6,50,'pcs','Low in Stock','Active',NULL,NULL),(13,'BONDING agent',1,50,'pcs','Low in Stock','Active',NULL,NULL),(14,'Brackets',26,50,'set','Low in Stock','Active',NULL,NULL),(15,'Buccal Tubes',0,50,'set','Out of Stock','Inactive',NULL,NULL),(16,'Burr -40 round',2,50,'pcs','Low in Stock','Active',NULL,NULL),(17,'Burrs # 368016',3,50,'pcs','Low in Stock','Active',NULL,NULL),(18,'Burrs diamond point (FG)',5,50,'pcs','Low in Stock','Active',NULL,NULL),(19,'Calibra esthetic Resin Cement',3,50,'pcs','Low in Stock','Active',NULL,NULL),(20,'Castone',12,50,'pcs','Low in Stock','Active',NULL,NULL),(21,'Cavitron',1,50,'pcs','Low in Stock','Active',NULL,NULL),(22,'Celluloid Strip',4,50,'pcs','Low in Stock','Active',NULL,NULL),(23,'Ceramic Brackets',4,50,'set','Low in Stock','Active',NULL,NULL),(24,'CLOSED COIL SPRING',6,50,'pcs','Low in Stock','Active',NULL,NULL),(25,'Coax',1,50,'packs','Low in Stock','Active',NULL,NULL),(26,'Composite A1',1,50,'pcs','Out of Stock','Active',NULL,NULL),(27,'Composite A2',3,50,'pcs','Low in Stock','Active',NULL,NULL),(28,'Composite A3',3,50,'pcs','Low in Stock','Active',NULL,NULL),(29,'Composite A3.5',4,50,'pcs','Low in Stock','Active',NULL,NULL),(30,'Composite A30',1,50,'pcs','Good','Active',NULL,NULL),(31,'Composite B2',2,50,'pcs','Low in Stock','Active',NULL,NULL),(32,'Composite Bonding Agent',1,50,'pcs','Low in Stock','Active',NULL,NULL),(33,'Composite instruments code-05703',1,50,'pcs','Low in Stock','Active',NULL,NULL),(34,'Composite instruments code-05707',1,50,'pcs','Low in Stock','Active',NULL,NULL),(35,'composite Inc.',11,50,'pcs','Low in Stock','Active',NULL,NULL),(36,'CuNiTi .016 Lower',1,50,'pcs','Low in Stock','Active',NULL,NULL),(37,'CuNiTi .12 Upper',1,50,'pcs','Low in Stock','Active',NULL,NULL),(38,'Defoger',4,50,'pcs','Low in Stock','Active',NULL,NULL),(39,'Dental Impression material tray',85,50,'pcs','Low in Stock','Active',NULL,NULL),(40,'Diestone',0,50,'pcs','Out of Stock','Active',NULL,NULL),(41,'Disposable Syringes 10cc',50,50,'pcs','Low in Stock','Active',NULL,NULL),(42,'Dowel Posts Large',4,50,'pcs','Low in Stock','Active',NULL,NULL),(43,'Dowel Posts Medium',4,50,'pcs','Low in Stock','Active',NULL,NULL),(44,'Dowel Posts Short',4,50,'pcs','Low in Stock','Active',NULL,NULL),(45,'DRIVER',1,50,'pcs','Low in Stock','Active',NULL,NULL),(46,'Dycal',2,50,'Pair','Good','Active',NULL,NULL),(47,'Elastic Chain',20,50,'pcs','Low in Stock','Active',NULL,NULL),(48,'Endo Block',1,50,'pcs','Low in Stock','Active',NULL,NULL),(49,'Etchant',1,50,'pcs','Low in Stock','Active',NULL,NULL),(50,'EX 12',7,50,'pcs','Good','Active',NULL,NULL),(51,'Expander Keys',13,50,'pcs','Good','Active',NULL,NULL),(52,'Face Masks',14,50,'Boxes','Good','Active',NULL,NULL),(53,'Fermine',1,50,'Bottles','Low in Stock','Active',NULL,NULL),(54,'Fishbone Trrays',2,50,'pcs','Low in Stock','Active',NULL,NULL),(55,'Fissure Burs',37,50,'pcs','Good','Active',NULL,NULL),(56,'Flouride Gel',38,50,'pcs','Good','Active',NULL,NULL),(57,'Flowable Composite A2',1,50,'pcs','Low in Stock','Active',NULL,NULL),(58,'Flowable Composite A3',0,50,'pcs','Out of Stock','Active',NULL,NULL),(59,'Flowable Composite A3.5',0,50,'pcs','Out of Stock','Active',NULL,NULL),(60,'Forestadent wire LOWER .012',4,50,'pcs','Low in Stock','Active',NULL,NULL),(61,'Forestadent wire UPER .012',5,50,'pcs','Low in Stock','Active',NULL,NULL),(62,'Formocresol',1,50,'pcs','Low in Stock','Active',NULL,NULL),(63,'gauze',0,50,'pcs','Out of Stock','Active',NULL,NULL),(64,'Gingi Master',1,50,'pcs','Low in Stock','Active',NULL,NULL),(65,'Gingi Master Refill',6,50,'pcs','Low in Stock','Active',NULL,NULL),(66,'Glass Ionomer Cement GIC',0,50,'Boxes','Out of Stock','Active',NULL,NULL),(67,'GLOVES LARGE',22,50,'Boxes','Good','Active',NULL,NULL),(68,'GLOVES SMALL',8,50,'Boxes','Good','Active',NULL,NULL),(69,'Goring',10,50,'Boxes','Good','Active',NULL,NULL),(70,'GS II FIXTURE',1,50,'pcs','Low in Stock','Active',NULL,NULL),(71,'Gun type w/ temp crown',1,50,'Set','Low in Stock','Active',NULL,NULL),(72,'Gutta Percha 15-40',0,50,'pcs','Out of Stock','Active',NULL,NULL),(73,'Gutta Percha 45-80',6,50,'Packs','Low in Stock','Active',NULL,NULL),(74,'HANDPIECE HIGHSPEED / yabangbang',0,50,'pcs','Out of Stock','Active',NULL,NULL),(75,'HANDPIECE NSK DYNALED/SURGERY',0,50,'Packs','Out of Stock','Active',NULL,NULL),(76,'HANDPIECE NSK PANAMAX',0,50,'pcs','Out of Stock','Active',NULL,NULL),(77,'HANDPIECE SET serial # 100300503',2,50,'set','Low in Stock','Active',NULL,NULL),(78,'HANDPIECE SET serial # 1100300503',0,50,'set','Out of Stock','Active',NULL,NULL),(79,'HANDPIECE SINGLE SET # 0074693',0,50,'pcs','Out of Stock','Active',NULL,NULL),(80,'HANDPIECE SINGLE SET # 0074694',0,50,'pcs','Out of Stock','Active',NULL,NULL),(81,'HANDPIECE SINGLE SET # 0074695',0,50,'pcs','Out of Stock','Active',NULL,NULL),(82,'HANDPIECE SINGLE SET # 0074696',0,50,'pcs','Out of Stock','Active',NULL,NULL),(83,'HANPIECE LUBRICANT',0,50,'pcs','Out of Stock','Active',NULL,NULL),(84,'HANDPIECE SINGLE SET # 0866090',0,50,'pcs','Out of Stock','Active',NULL,NULL),(85,'Hemodent',1,50,'Bottles','Low in Stock','Active',NULL,NULL),(86,'H-FILE 015-040',3,50,'pcs','Low in Stock','Active',NULL,NULL),(87,'IRM',0,50,'pcs','Out of Stock','Active',NULL,NULL),(88,'K-Files #10 21mm',11,50,'pcs','Good','Active',NULL,NULL),(89,'Ligatice',167,50,'pcs','Good','Active',NULL,NULL),(90,'Ligature wire',0,50,'pcs','Out of Stock','Active',NULL,NULL),(91,'LIIDOCAINE hcl',0,50,'pcs','Out of Stock','Active',NULL,NULL),(92,'Luminous Dappen Dish',12,50,'pcs','Good','Active',NULL,NULL),(93,'Matrix band universal',18,50,'pcs','Good','Active',NULL,NULL),(94,'METAPEX',1,50,'pcs','Low in Stock','Active',NULL,NULL),(95,'Mixing Pad Big',3,50,'pcs','Low in Stock','Active',NULL,NULL),(96,'Mixing Pad Small',0,50,'pcs','Out of Stock','Active',NULL,NULL),(97,'Modeling compound',0,50,'pcs','Out of Stock','Active',NULL,NULL),(98,'Molar bands',72,50,'pcs','Good','Active',NULL,NULL),(99,'NiTi .012 lower',8,50,'pcs','Good','Active',NULL,NULL),(100,'NiTi .012 upper',9,50,'pcs','Good','Active',NULL,NULL);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (103,'2014_10_12_000000_create_users_table',1),(104,'2014_10_12_100000_create_password_resets_table',1),(105,'2018_03_14_074254_create_patients_table',1),(106,'2018_03_18_033440_create_inventories_table',1),(107,'2018_03_22_144428_create_services_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `patID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patientTelNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthDate` date NOT NULL,
  `age` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `medconditions` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allergies` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` int(11) NOT NULL,
  `patStatus` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`patID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'Gandeza Rachel E','Marville Subdivision Irisan Baguio City','Student','9260717250','Single','0000-00-00','24','F','','',0,'active',NULL,NULL),(2,'Maria Olivia Margaris','Marville Subdivision Baguio City','Security Guard','9193279345','Married','0000-00-00','35','F','','',0,'active',NULL,NULL),(3,'Di Anne P Monreal','Bakakeng Sur Baguio City','Cabin Crew','9173024102','Single','0000-00-00','26','F','','',0,'active',NULL,NULL),(4,'Jesssie G. Bautista','Honeymonon RD Baguio City','Maintenance','9302184788','Married','0000-00-00','27','M','','',0,'active',NULL,NULL),(5,'Joan Polomen','','Student','9282817870','Married','0000-00-00','34','F','','',0,'active',NULL,NULL),(6,'Jhoairha Manaiang','','Civil Engineer','9653265299','Single','0000-00-00','17','M','','',0,'active',NULL,NULL),(7,'Magilyn Lim','7 Laubach Road Baguio City','Flight Attendant','9277948873','Married','0000-00-00','40','F','','',0,'active',NULL,NULL),(8,'Kailey Robyn C. Bernal','129E Leonila Mill','Student','9778560101','Single','0000-00-00','8','F','','',0,'active',NULL,NULL),(9,'Rexelle Jun R. Bersamin','North Cambridge Condominium Bakakeng Baguio City','Security Guard','9269350953','Single','0000-00-00','23','M','','',0,'active',NULL,NULL),(10,'charice Costales','2A-11 Ledesma St. Aurora Hil Baguio City','HouseWife','244-2461','Married','0000-00-00','29','f','','',0,'active',NULL,NULL);
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `payID` int(11) NOT NULL AUTO_INCREMENT,
  `datePaid` date NOT NULL,
  `amount` int(11) NOT NULL,
  `receive` varchar(45) NOT NULL,
  PRIMARY KEY (`payID`),
  UNIQUE KEY `payID_UNIQUE` (`payID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `record`
--

DROP TABLE IF EXISTS `record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `record` (
  `recordID` int(11) NOT NULL AUTO_INCREMENT,
  `dentist` varchar(45) NOT NULL,
  `servPeformed` varchar(45) NOT NULL,
  `patient` varchar(45) NOT NULL,
  `payment` int(11) NOT NULL,
  PRIMARY KEY (`recordID`),
  UNIQUE KEY `recordID_UNIQUE` (`recordID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record`
--

LOCK TABLES `record` WRITE;
/*!40000 ALTER TABLE `record` DISABLE KEYS */;
/*!40000 ALTER TABLE `record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `schedID` int(11) NOT NULL AUTO_INCREMENT,
  `scheduledDate` date NOT NULL,
  `timeFrom` time NOT NULL,
  `timeTo` time NOT NULL,
  PRIMARY KEY (`schedID`),
  UNIQUE KEY `schedID_UNIQUE` (`schedID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serperinventory`
--

DROP TABLE IF EXISTS `serperinventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serperinventory` (
  `invQty` int(11) NOT NULL,
  `service` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serperinventory`
--

LOCK TABLES `serperinventory` WRITE;
/*!40000 ALTER TABLE `serperinventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `serperinventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `servID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `servName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`servID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'Dental Implants',0,NULL,NULL),(2,'Dentures',0,NULL,NULL),(3,'Dental Filiings',0,NULL,NULL),(4,'Root Canal',0,NULL,NULL),(5,'Teeth Whitening',0,NULL,NULL);
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serviceschedule`
--

DROP TABLE IF EXISTS `serviceschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serviceschedule` (
  `serPref` int(11) NOT NULL,
  `schedDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serviceschedule`
--

LOCK TABLES `serviceschedule` WRITE;
/*!40000 ALTER TABLE `serviceschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `serviceschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'jay','Jay@test.com','$2y$10$5RM6F6BXUY.HdH3d7T.viuB0lbe9yxjxUpzCflYhIJ9NNRT9dc9xK',NULL,'2018-03-22 07:31:48','2018-03-22 07:31:48');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'gab'
--

--
-- Dumping routines for database 'gab'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-03-23  0:02:19
