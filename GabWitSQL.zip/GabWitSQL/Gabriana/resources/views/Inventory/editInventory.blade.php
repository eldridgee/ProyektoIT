@extends('layouts.adminLayout')

@section('content')
<div class="wrapper">
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Edit inventory item
            </h1>
            <ol class="breadcrumb">
                <li><a href="/admin"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="">Inventory</li>
                <li class="active">Edit Inventory</li>
            </ol>
        </section>

        <div class="well">
            {!! Form::open(['action' => ['InventoryController@update', $inventory->invID], 'method' => 'POST']) !!}
            
            <div class="form-group">
                {{Form::label('invName', 'Name')}}
                {{Form::text('invName', $inventory->invName, ['class' => 'form-control', 'placeholder' => 'Inventory Name'])}}
            </div>

            <div class="form-group">
                    {{Form::label('quantity', 'Quantity')}}
                    {{Form::text('quantity', $inventory->quantity, ['class' => 'form-control', 'placeholder' => 'Initial Quantity'])}}
            </div>

            <div class="form-group">
                    {{Form::label('low_stock_quantity', 'Low Stock Quantity')}}
                    {{Form::text('low_stock_quantity', $inventory->low_stock_quantity, ['class' => 'form-control', 'placeholder' => 'Enter the Low Stock Quantity'])}}
            </div>

            <div class="form-group">
                    {{Form::label('unit', 'Unit Category')}}
                    {{Form::text('unit', $inventory->unit, ['class' => 'form-control', 'placeholder' => 'Enter the Unit category (e.g. Box, Pieces)'])}}
            </div>

            <div class="form-group">
                {{Form::label('invStatus', 'Inventory Status')}}
                {{Form::text('invStatus', $inventory->invStatus, ['class' => 'form-control', 'placeholder' => 'e.g. Low in Stock, No Stock, Good'])}}
            </div>

            <div class="form-group">
                {{Form::label('status', 'Status')}}
                {{Form::text('status', $inventory->status, ['class' => 'form-control', 'placeholder' => 'Active or Inactive'])}}
            </div>
            {{Form::hidden('_method', 'PUT')}}
            <div class="box-footer">
                <a href="/inventory" class="btn btn-default">Cancel</a>
                {{Form::submit('Submit', ['class'=>'btn btn-primary pull-right']) }}
            </div>
            {!! Form::close() !!}
        </div>
      
</div>
@endsection