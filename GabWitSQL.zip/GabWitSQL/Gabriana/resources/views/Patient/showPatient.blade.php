@extends('layouts.adminLayout')

@section('content')

    <div class="content-wrapper" style="min-height: 1126px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        {{$patient->name}}
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="/patient">Records</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Patient Information</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Name :</td>
                            <td>{{$patient->name}}</td>
                        </tr>
                          <tr>
                            <td>Address :</td>
                            <td>{{$patient->address}}</td>
                          </tr>
                          <tr>
                            <td>Occupation :</td>
                            <td>{{$patient->occupation}}</td>
                          </tr>
                          <tr>
                              <td>Contact Number :</td>
                            <td>{{$patient->patientTelNo}}</td>
                          </tr>
                          <tr>
                            <td>Civil Status</td>
                            <td>{{$patient->status}}</td>
                          </tr>
                          <tr>
                              <td>Date of Birth :</td>
                            <td>{{$patient->birthDate}}</td>
                          </tr>
                          <tr>
                              <td>Age :</td>
                            <td>{{$patient->age}}</td>
                          </tr>
                          <tr>
                              <td>Gender :</td>
                            <td>{{$patient->sex}}</td>
                          </tr>
                          <tr>
                              <td>Medical Conditions :</td>
                            <td>{{$patient->medconditions}}</td>
                          </tr>
                          <tr>
                              <td>Allergies :</td>
                            <td>{{$patient->allergies}}</td>
                            </tr>
                          <tr>
                            <td>Balance :</td>
                            <td>{{$patient->balance}}</td>
                            </tr>
                          </tr>
                          <tr>
                              <td>Patient Status :</td>
                            <td>{{$patient->patStatus}}</td>
                          </tr>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <a href="/patient" class="btn btn-default">Cancel</a>
                <a href="/patient/{{$patient->patID}}/edit" class="btn btn-primary pull-right">Edit</a>
            </div>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>


@endsection


