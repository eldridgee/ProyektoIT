<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Inventory;

class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $inventory = Inventory::all();
        return view('Inventory.inventory')->with('inventory', $inventory);
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view ('Inventory.createNewInventory');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'invName' => 'required',
            'quantity' => 'required',
            'low_stock_quantity' => 'required',
            'unit' => 'required',
            'invStatus' => 'required',
            'status' => 'required',
        ]);

        $inventory = new Inventory;
        $inventory->invName = $request->input('invName');
        $inventory->quantity = $request->input('quantity');
        $inventory->low_stock_quantity = $request->input('low_stock_quantity');
        $inventory->unit = $request->input('unit');
        $inventory->invStatus = $request->input('invStatus');
        $inventory->status = $request->input('status');
        $inventory->save();

        return redirect('/inventory')->with('success', 'New Inventory Created');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($invID)
    {
       $inventory = Inventory::find($invID);
       return view('Inventory.showInventory')->with('inventory', $inventory); 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($invID)
    {
        $inventory = Inventory::find($invID);
        return view('Inventory.editInventory')->with('inventory', $inventory);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $invID)
    {
        $this->validate($request, [
            'invName' => 'required',
            'quantity' => 'required',
            'low_stock_quantity' => 'required',
            'unit' => 'required',
            'invStatus' => 'required',
            'status' => 'required',
        ]);
        
        $inventory = Inventory::find($invID);
        $inventory->invName = $request->input('invName');
        $inventory->quantity = $request->input('quantity');
        $inventory->low_stock_quantity = $request->input('low_stock_quantity');
        $inventory->unit = $request->input('unit');
        $inventory->invStatus = $request->input('invStatus');
        $inventory->status = $request->input('status');
        $inventory->save();

        return redirect('/inventory')->with('success', 'Inventory item information updated');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($invID)
    {
        //
    }
}
