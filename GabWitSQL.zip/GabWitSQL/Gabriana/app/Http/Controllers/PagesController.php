<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Service;

class pagesController extends Controller
{
    public function admin()
    {
        $services = Service::all();
        return view('Admin.admin')->with('services', $services);
    }

    public function admin2()
    {
        return view('pages.admin2');
    }

    public function log()
    {
        return view('auth.login');
    }

    public function trypage()
    {
        return view('pages.try');
    }

    public function datatibil()
    {
        return view('pages.datatibil');
    }
}
